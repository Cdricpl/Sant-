import { useLocalStorage } from "@/hooks/use-local-storage";
import type { Appointment, Medication, MedLog, WeightEntry, Child } from "@/lib/types";
import { Card } from "@/components/ui/card";
import { Activity, Pill, CalendarDays, Baby, FlaskConical } from "lucide-react";

const todayKey = () => new Date().toISOString().slice(0, 10);

export function AccueilTab({ onGo }: { onGo: (tab: string) => void }) {
  const [weightsMoi] = useLocalStorage<WeightEntry[]>("sante:suivi:moi", []);
  const [weightsLegacy] = useLocalStorage<WeightEntry[]>("sante:suivi", []);
  const weights = weightsMoi.length > 0 ? weightsMoi : weightsLegacy;
  const [meds] = useLocalStorage<Medication[]>("sante:meds", []);
  const [log] = useLocalStorage<MedLog>("sante:medlog", {});
  const [rdv] = useLocalStorage<Appointment[]>("sante:rdv", []);
  const [children] = useLocalStorage<Child[]>("sante:children", []);

  const last = weights[0];
  const bmi =
    last && last.height ? (last.weight / Math.pow(last.height / 100, 2)).toFixed(1) : "—";

  const day = todayKey();
  const todayDoses = meds.flatMap((m) => m.times.map((t) => ({ medId: m.id, t })));
  const taken = todayDoses.filter((d) => log[`${day}|${d.medId}|${d.t}`]).length;

  const lastRdv = [...rdv].sort((a, b) => b.date.localeCompare(a.date))[0];

  const cards = [
    {
      label: "Poids",
      value: last ? `${last.weight} kg` : "—",
      sub: last ? `IMC ${bmi}` : "Aucune mesure",
      icon: Activity,
      tab: "suivi",
      tone: "bg-primary-soft text-primary",
    },
    {
      label: "Médicaments",
      value: todayDoses.length ? `${taken}/${todayDoses.length}` : "—",
      sub: "Pris aujourd'hui",
      icon: Pill,
      tab: "pilulier",
      tone: "bg-accent-soft text-accent",
    },
    {
      label: "Dernier RDV",
      value: lastRdv ? lastRdv.kind : "—",
      sub: lastRdv
        ? new Date(lastRdv.date).toLocaleDateString("fr-FR")
        : "Aucun rendez-vous",
      icon: CalendarDays,
      tab: "rdv",
      tone: "bg-warning-soft text-warning",
    },
    {
      label: "Enfants",
      value: String(children.length),
      sub: children.map((c) => c.name).join(", ") || "Aucun",
      icon: Baby,
      tab: "enfants",
      tone: "bg-primary-soft text-primary",
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Bonjour 👋</h2>
        <p className="text-sm text-muted-foreground">
          Voici un aperçu de votre santé aujourd'hui.
        </p>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        {cards.map((c) => {
          const Icon = c.icon;
          return (
            <button
              key={c.label}
              onClick={() => onGo(c.tab)}
              className="text-left"
            >
              <Card className="p-4 transition hover:shadow-md">
                <div className="flex items-center gap-3">
                  <div className={`flex h-11 w-11 items-center justify-center rounded-xl ${c.tone}`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs uppercase tracking-wide text-muted-foreground">
                      {c.label}
                    </p>
                    <p className="truncate font-semibold">{c.value}</p>
                    <p className="truncate text-xs text-muted-foreground">{c.sub}</p>
                  </div>
                </div>
              </Card>
            </button>
          );
        })}
      </div>

      <Card className="p-5">
        <div className="flex items-center gap-3">
          <FlaskConical className="h-5 w-5 text-primary" />
          <div>
            <p className="font-semibold">Analyses de sang</p>
            <p className="text-sm text-muted-foreground">
              Suivez vos biomarqueurs dans le temps.
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}
